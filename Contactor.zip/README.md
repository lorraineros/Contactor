# Contactor
### npm i
to install modules
### npm start
to run project